#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import "os/lock.h"



extern CMMemoryPoolRef		_HIAVFMemPool;
extern CFAllocatorRef		_HIAVFMemPoolAllocator;
extern os_unfair_lock		_HIAVFMemPoolLock;



