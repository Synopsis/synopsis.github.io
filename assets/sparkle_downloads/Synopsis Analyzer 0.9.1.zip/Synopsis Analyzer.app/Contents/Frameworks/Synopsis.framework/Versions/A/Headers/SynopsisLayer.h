//
//  SynopsisLayer.h
//  Synopsis-Framework
//
//  Created by vade on 4/20/17.
//  Copyright © 2017 v002. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface SynopsisLayer : CALayer


@end
